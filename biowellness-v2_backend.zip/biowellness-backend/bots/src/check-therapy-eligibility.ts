import { BotEvent, MedplumClient, getReferenceString, resolveId } from '@medplum/core';
import type {
  DiagnosticReport, DetectedIssue, Observation, Patient, PlanDefinition, Reference,
} from '@medplum/fhirtypes';

/**
 * Bot: Gating de terapias (elegibilidad / riesgo) — DATA-DRIVEN.
 *
 * Las reglas NO están hardcodeadas: se leen del PlanDefinition
 * "BioWellness — Gating de Terapias" (type=eca-rule), que se carga como FHIR
 * (biowellness_plandefinition_gating_bundle.json) y se edita en la app.
 *
 * Disparo: Subscription sobre DiagnosticReport final.
 *   - Lee las Observation del informe.
 *   - Por cada regla (action del PlanDefinition con parámetros numéricos):
 *       condición cumplida → DetectedIssue ACTIVO (contraindicación)
 *       condición NO cumplida → resuelve el DetectedIssue previo (status=cancelled + mitigation)
 *   - Upsert idempotente por (patient + gateId).
 *
 * Reglas sin umbral numérico (p.ej. HRV "baja sostenida") se omiten acá: se evalúan
 * con datos de wearables, no en un laboratorio.
 */

const BIO = 'https://bio.medplum.com.ar/fhir';
const GATE_SYS = `${BIO}/CodeSystem/gate-terapia`;
const GP_EXT = `${BIO}/StructureDefinition/gate-parametros`;
const PLANDEF_URL = `${BIO}/PlanDefinition/gating-terapias`;
const LOINC = 'http://loinc.org';

type Op = '>' | '<' | '>=' | '<=';
interface Gate {
  id: string; label: string; loinc?: string; nameIncludes?: string;
  op: Op; threshold: number; unit: string;
  blocks: string[]; severity: 'high' | 'moderate' | 'low'; message: string;
}

function ext(arr: any[] | undefined, url: string): any | undefined {
  return (arr ?? []).find((e) => e.url === url);
}

/** Carga las reglas desde el PlanDefinition de gating. */
async function loadGates(medplum: MedplumClient): Promise<Gate[]> {
  const pds = await medplum.searchResources('PlanDefinition', { url: PLANDEF_URL });
  const gates: Gate[] = [];
  for (const pd of pds as PlanDefinition[]) {
    for (const action of pd.action ?? []) {
      const gp = ext(action.extension, GP_EXT);
      if (!gp) continue;
      const subs = gp.extension ?? [];
      const op = ext(subs, 'operador')?.valueCode as Op | undefined;
      const threshold = ext(subs, 'umbral')?.valueDecimal;
      if (!op || threshold == null) continue; // omite reglas no numéricas (HRV)
      gates.push({
        id: ext(subs, 'gateId')?.valueCode ?? action.title ?? 'GATE',
        label: action.title ?? 'Gate',
        loinc: ext(subs, 'loinc')?.valueCode,
        nameIncludes: ext(subs, 'nombreContiene')?.valueString,
        op,
        threshold,
        unit: ext(subs, 'unidad')?.valueString ?? '',
        blocks: subs.filter((s: any) => s.url === 'bloquea').map((s: any) => s.valueString),
        severity: (ext(subs, 'severidad')?.valueCode as Gate['severity']) ?? 'moderate',
        message: action.description ?? '',
      });
    }
  }
  return gates;
}

function normName(s: string): string {
  return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
}
function meets(op: Op, v: number, t: number): boolean {
  return op === '>' ? v > t : op === '<' ? v < t : op === '>=' ? v >= t : v <= t;
}
function findValue(obs: Observation[], gate: Gate): { value: number; obs: Observation } | undefined {
  if (gate.loinc) {
    const o = obs.find((x) => x.code?.coding?.some((c) => c.system === LOINC && c.code === gate.loinc));
    if (o?.valueQuantity?.value != null) return { value: o.valueQuantity.value, obs: o };
  }
  if (gate.nameIncludes) {
    const o = obs.find((x) => normName(x.code?.text ?? '').includes(gate.nameIncludes!));
    if (o?.valueQuantity?.value != null) return { value: o.valueQuantity.value, obs: o };
  }
  return undefined;
}

export async function handler(medplum: MedplumClient, event: BotEvent<DiagnosticReport>): Promise<DetectedIssue[]> {
  const report = event.input;
  const patientRef = report.subject as Reference<Patient> | undefined;
  const patientId = patientRef ? resolveId(patientRef) : undefined;
  if (!patientId) throw new Error('El DiagnosticReport no tiene un subject Patient.');

  const gates = await loadGates(medplum);
  if (!gates.length) {
    console.log('No hay reglas de gating cargadas (PlanDefinition gating-terapias). Nada que evaluar.');
    return [];
  }

  const obs: Observation[] = [];
  for (const r of report.result ?? []) {
    const o = await medplum.readReference(r as Reference<Observation>).catch(() => undefined);
    if (o) obs.push(o as Observation);
  }

  const issues: DetectedIssue[] = [];
  for (const gate of gates) {
    const found = findValue(obs, gate);
    const existing = await medplum.searchOne<DetectedIssue>(
      'DetectedIssue',
      `patient=Patient/${patientId}&code=${GATE_SYS}|${gate.id}`
    );
    if (!found) continue; // biomarcador no presente en este informe
    const active = meets(gate.op, found.value, gate.threshold);

    if (active) {
      const di: DetectedIssue = {
        resourceType: 'DetectedIssue',
        ...(existing ? { id: existing.id } : {}),
        identifier: [{ system: GATE_SYS, value: `${gate.id}-${patientId}` }],
        status: 'final',
        code: { coding: [{ system: GATE_SYS, code: gate.id, display: gate.label }], text: gate.label },
        severity: gate.severity,
        patient: { reference: `Patient/${patientId}` },
        identifiedDateTime: new Date().toISOString(),
        implicated: [{ reference: getReferenceString(found.obs) }],
        evidence: [{ detail: [{ reference: getReferenceString(found.obs) }] }],
        detail:
          `${gate.message} Valor: ${found.value} ${gate.unit} (corte ${gate.op} ${gate.threshold}). ` +
          `Terapias bloqueadas: ${gate.blocks.join(', ')}.`,
      };
      issues.push(existing
        ? await medplum.updateResource<DetectedIssue>(di)
        : await medplum.createResource<DetectedIssue>(di));
    } else if (existing && existing.status === 'final') {
      issues.push(await medplum.updateResource<DetectedIssue>({
        ...existing,
        status: 'cancelled',
        mitigation: [
          ...(existing.mitigation ?? []),
          { action: { text: `Resuelto: ${gate.label} normalizado (${found.value} ${gate.unit}).` }, date: new Date().toISOString() },
        ],
      }));
    }
  }
  return issues;
}
