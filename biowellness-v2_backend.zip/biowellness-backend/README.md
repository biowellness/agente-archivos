# BioWellness — Backend FHIR R4 (catálogo + reglas + Bots)

Paquete para el repo `biowellness/agente-archivos`. El **portal de pacientes**
(login, subida de PDF, Consent, AccessPolicy) queda intacto; esto agrega/actualiza
el **catálogo de biomarcadores**, las **reglas de gating** y los **Bots** del servidor.

API FHIR: `https://api.medplum.com.ar/fhir/R4` · App: `https://app.medplum.com.ar`

## Qué se carga en Medplum y qué no  <-- leé esto primero

| Archivo | ¿Es FHIR? | ¿Se carga? | Qué es |
|---|---|---|---|
| `biowellness_observationdefinition_bundle*.json` | SI (ObservationDefinition) | SI | Los **biomarcadores** con rango convencional + óptimo. Ya cargados (50). |
| `biowellness_plandefinition_gating_bundle.json` | SI (PlanDefinition) | SI | Las **reglas** de bloqueo de terapias. |
| `biowellness_stamboulian_bundle.json` | SI (Bundle) | opcional | Laboratorio de ejemplo para probar. |
| `biomarker_master.json` | NO | NO | Fuente normalizada para regenerar el catálogo y el diccionario del Bot. |
| `reglas_gating_terapias.json` | NO | NO | Fuente legible desde la que se genera el PlanDefinition. |

Regla mental: **Biomarcadores = ObservationDefinition** · **Reglas = PlanDefinition**.
Los `*_master.json` y `reglas_*.json` son insumos de desarrollo, NO se suben a Medplum.

## Flujo

```
Portal (repo)  --> DocumentReference (PDF + Consent)
                     |  Subscription
                     v
              parse-lab-report  --> Observation (panel + rango funcional) + DiagnosticReport
                                         |  Subscription
                                         v
                              check-therapy-eligibility  --> DetectedIssue (contraindicaciones)
                                   ^  lee las reglas de
                                   +-- PlanDefinition (gating-terapias)
```

## 0) Prerrequisitos

```bash
npm install -g @medplum/cli
export MEDPLUM_BASE_URL=https://api.medplum.com.ar/
export MEDPLUM_CLIENT_ID=<client_id>        # ClientApplication con AccessPolicy de admin
export MEDPLUM_CLIENT_SECRET=<client_secret>
```

## 1) Cargar Biomarcadores (catalogo FHIR)

ObservationDefinition no tiene search param `identifier`, por eso POST (primera carga)
o PUT por id deterministico (re-seed idempotente).

```bash
cat catalog/biowellness_observationdefinition_bundle.json | medplum post 'fhir/R4' -
medplum get 'fhir/R4/ObservationDefinition?_summary=count'   # total = 50
# re-seed sin duplicar (cuando edites la tabla):
# cat catalog/biowellness_observationdefinition_bundle_idempotente.json | medplum post 'fhir/R4' -
```

## 2) Cargar Reglas (PlanDefinition FHIR)

```bash
cat catalog/biowellness_plandefinition_gating_bundle.json | medplum post 'fhir/R4' -
medplum get 'fhir/R4/PlanDefinition?url=https://bio.medplum.com.ar/fhir/PlanDefinition/gating-terapias'
```

El Bot de gating las lee de aca. Para cambiar un umbral, editas el PlanDefinition en la
app (o regeneras el bundle con catalog/build_gating_plandefinition.py desde
reglas_gating_terapias.json y lo recargas). NO hay que redeployar el Bot.

## 3) Compilar los bots

```bash
cd bots && npm install && npm run build && cd ..
```

## 4) Crear los Bots y desplegarlos

```bash
medplum post 'fhir/R4/Bot' '{"resourceType":"Bot","name":"parse-lab-report","runtimeVersion":"awslambda"}'
medplum post 'fhir/R4/Bot' '{"resourceType":"Bot","name":"check-therapy-eligibility","runtimeVersion":"awslambda"}'
# pega los "id" en medplum.config.json (REEMPLAZAR_BOT_ID_PARSE / _GATING), luego:
medplum bot deploy parse-lab-report
medplum bot deploy check-therapy-eligibility
```

## 5) Secret del Project

ANTHROPIC_API_KEY (lo usa parse-lab-report). App: Project -> Secrets.

## 6) Subscriptions

```bash
medplum post 'fhir/R4/Subscription' '{
  "resourceType":"Subscription","status":"active","reason":"Parsear/enriquecer laboratorios",
  "criteria":"DocumentReference?status=current",
  "channel":{"type":"rest-hook","endpoint":"Bot/<BOT_ID_PARSE>"}}'

medplum post 'fhir/R4/Subscription' '{
  "resourceType":"Subscription","status":"active","reason":"Gating de terapias",
  "criteria":"DiagnosticReport?status=final",
  "channel":{"type":"rest-hook","endpoint":"Bot/<BOT_ID_GATING>"}}'
```

## 7) Probar punta a punta

Subi un PDF por el portal con consentimiento y verifica la cadena:

```bash
medplum get 'fhir/R4/Observation?patient=Patient/<ID>&_sort=-_lastUpdated'   # panel + rango funcional
medplum get 'fhir/R4/DiagnosticReport?patient=Patient/<ID>'
medplum get 'fhir/R4/DetectedIssue?patient=Patient/<ID>&status=final'        # contraindicaciones
```

## Fases

- Fase 1 (ingesta): pasos 1, 3-6 con parse-lab-report.
- Fase 2 (riesgo): paso 2 + check-therapy-eligibility. Encenderlo tras validar la ingesta.

## Pendiente (Bloque 0)

Registrar como recursos FHIR los CodeSystem: panel-biomarcador, contexto-rango,
biomarcador-local, gate-terapia. Medplum acepta los codigos igual; registrarlos da
validacion de terminologia.
