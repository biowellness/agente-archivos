import { BotEvent, MedplumClient, getReferenceString, resolveId } from '@medplum/core';
import type { DiagnosticReport, DetectedIssue, Observation, Patient, Reference } from '@medplum/fhirtypes';

/**
 * Bot: Gating de terapias (elegibilidad / riesgo).
 *
 * Se dispara por una Subscription cuando se crea/actualiza un DiagnosticReport final.
 * Lee las Observation del informe, evalúa las reglas de bloqueo de BioWellness
 * (de reglas_gating_terapias.json) y materializa el resultado como DetectedIssue:
 *   - Si la condición se cumple  → contraindicación ACTIVA (status=final, severity alta/moderada),
 *     con el biomarcador como evidencia y las terapias bloqueadas en el detalle.
 *   - Si NO se cumple            → se resuelve cualquier contraindicación previa (status=cancelled + mitigation).
 *
 * Upsert idempotente por (patient + code del gate): no duplica DetectedIssue al re-evaluar.
 *
 * Nota: el gate de HRV se evalúa con datos de wearables, no en un laboratorio,
 * así que este Bot (disparado por DiagnosticReport) sólo cubre los gates de laboratorio.
 */

const GATE_SYS = 'https://bio.medplum.com.ar/fhir/CodeSystem/gate-terapia';
const LOINC = 'http://loinc.org';

type Op = '>' | '<' | '>=' | '<=';
interface Gate {
  id: string;
  label: string;
  loinc?: string;            // match primario por LOINC
  nameIncludes?: string;     // fallback por nombre normalizado
  op: Op;
  threshold: number;
  unit: string;
  blocks: string[];          // terapias bloqueadas
  severity: 'high' | 'moderate' | 'low';
  message: string;
}

// Reglas de reglas_gating_terapias.json (embebidas; pueden externalizarse a un recurso de config)
const GATES: Gate[] = [
  {
    id: 'GATE-PCR', label: 'PCR-us elevada', loinc: '30522-7', nameIncludes: 'pcr',
    op: '>', threshold: 1.0, unit: 'mg/L', blocks: ['terapias-biologicas'], severity: 'high',
    message: 'PCR-us > 1 mg/L: priorizar microbiota/redox antes de avanzar a terapias biológicas.',
  },
  {
    id: 'GATE-HOMA', label: 'Resistencia insulínica', nameIncludes: 'homa',
    op: '>', threshold: 2.0, unit: '{index}', blocks: ['protocolos-regenerativos'], severity: 'high',
    message: 'HOMA-IR > 2: corregir resistencia insulínica antes de protocolos regenerativos.',
  },
  {
    id: 'GATE-FERRITINA', label: 'Ferritina baja', loinc: '2276-4', nameIncludes: 'ferritina',
    op: '<', threshold: 30.0, unit: 'ng/mL', blocks: ['hiit', 'hormesis-intensa'], severity: 'moderate',
    message: 'Ferritina < 30 ng/mL: no realizar HIIT ni hormesis intensa (depleción de hierro).',
  },
];

function normName(s: string): string {
  return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
}

function meets(op: Op, value: number, t: number): boolean {
  return op === '>' ? value > t : op === '<' ? value < t : op === '>=' ? value >= t : value <= t;
}

interface FoundValue { value: number; obs: Observation; }

function findValue(obs: Observation[], gate: Gate): FoundValue | undefined {
  // 1) por LOINC
  if (gate.loinc) {
    const o = obs.find((x) => x.code?.coding?.some((c) => c.system === LOINC && c.code === gate.loinc));
    if (o?.valueQuantity?.value != null) return { value: o.valueQuantity.value, obs: o };
  }
  // 2) por nombre
  if (gate.nameIncludes) {
    const o = obs.find((x) => normName(x.code?.text ?? '').includes(gate.nameIncludes!));
    if (o?.valueQuantity?.value != null) return { value: o.valueQuantity.value, obs: o };
  }
  return undefined;
}

export async function handler(medplum: MedplumClient, event: BotEvent<DiagnosticReport>): Promise<DetectedIssue[]> {
  const report = event.input;
  const patientRef = report.subject as Reference<Patient> | undefined;
  const patientId = patientRef ? resolveId(patientRef) : undefined;
  if (!patientId) {
    throw new Error('El DiagnosticReport no tiene un subject Patient.');
  }

  // Cargar las Observation del informe
  const obs: Observation[] = [];
  for (const r of report.result ?? []) {
    const o = await medplum.readReference(r as Reference<Observation>).catch(() => undefined);
    if (o) obs.push(o as Observation);
  }

  const issues: DetectedIssue[] = [];

  for (const gate of GATES) {
    const found = findValue(obs, gate);

    // Buscar contraindicación previa para este gate + paciente (upsert idempotente)
    const existing = await medplum.searchOne<DetectedIssue>(
      'DetectedIssue',
      `patient=Patient/${patientId}&code=${GATE_SYS}|${gate.id}`
    );

    // Si no podemos evaluar (no está el biomarcador en este informe), no tocamos nada
    if (!found) continue;

    const active = meets(gate.op, found.value, gate.threshold);

    if (active) {
      const di: DetectedIssue = {
        resourceType: 'DetectedIssue',
        ...(existing ? { id: existing.id } : {}),
        identifier: [{ system: GATE_SYS, value: `${gate.id}-${patientId}` }],
        status: 'final',
        code: { coding: [{ system: GATE_SYS, code: gate.id, display: gate.label }], text: gate.label },
        severity: gate.severity,
        patient: { reference: `Patient/${patientId}` },
        identifiedDateTime: new Date().toISOString(),
        implicated: [{ reference: getReferenceString(found.obs) }],
        evidence: [{ detail: [{ reference: getReferenceString(found.obs) }] }],
        detail:
          `${gate.message} Valor: ${found.value} ${gate.unit} (corte ${gate.op} ${gate.threshold}). ` +
          `Terapias bloqueadas: ${gate.blocks.join(', ')}.`,
      };
      const saved = existing
        ? await medplum.updateResource<DetectedIssue>(di)
        : await medplum.createResource<DetectedIssue>(di);
      issues.push(saved);
    } else if (existing && existing.status === 'final') {
      // El valor se normalizó → resolver la contraindicación previa
      const resolved = await medplum.updateResource<DetectedIssue>({
        ...existing,
        status: 'cancelled',
        mitigation: [
          ...(existing.mitigation ?? []),
          {
            action: { text: `Resuelto: ${gate.label} normalizado (${found.value} ${gate.unit}).` },
            date: new Date().toISOString(),
          },
        ],
      });
      issues.push(resolved);
    }
  }

  return issues;
}
