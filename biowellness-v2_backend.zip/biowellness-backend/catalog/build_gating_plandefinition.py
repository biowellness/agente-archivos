#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Convierte reglas_gating_terapias.json en un Bundle FHIR R4 con un PlanDefinition
(type=eca-rule) cuyas 'action' son las reglas de gating. Cada action lleva los
parámetros estructurados en una extensión 'gate-parametros' que el Bot lee.

Idempotente: PUT por id UUID determinístico (Medplum exige id con formato UUID).
La 'url' canónica queda legible y es la que el Bot usa para buscar el recurso.
"""
import json, uuid

BIO = "https://bio.medplum.com.ar/fhir"
GP_EXT = f"{BIO}/StructureDefinition/gate-parametros"
PLANDEF_URL = f"{BIO}/PlanDefinition/gating-terapias"
PD_ID = str(uuid.uuid5(uuid.NAMESPACE_URL, PLANDEF_URL))  # UUID estable derivado de la url

rules = json.load(open("reglas_gating_terapias.json"))["reglas"]

META = {
    "GATE-PCR":       {"sev": "high",     "name": "pcr",       "label": "PCR-us elevada"},
    "GATE-HOMA":      {"sev": "high",     "name": "homa",      "label": "Resistencia insulínica (HOMA-IR)"},
    "GATE-FERRITINA": {"sev": "moderate", "name": "ferritina", "label": "Ferritina baja"},
    "GATE-HRV":       {"sev": "moderate", "name": "hrv",       "label": "HRV baja sostenida"},
}

def fhirpath(r):
    cond = r["condicion"]
    if cond.get("op") in (">", "<", ">=", "<=") and r.get("loinc"):
        return f"Observation.where(code.coding.code='{r['loinc']}').value.ofType(Quantity).value {cond['op']} {cond['valor']}"
    if cond.get("op") in (">", "<", ">=", "<="):
        return f"valor del biomarcador '{META[r['id']]['name']}' {cond['op']} {cond['valor']}"
    return "HRV RMSSD bajo sostenido (se evalúa con datos de wearables)"

actions = []
for r in rules:
    m = META[r["id"]]; cond = r["condicion"]
    sub = [{"url": "gateId", "valueCode": r["id"]}]
    if r.get("loinc"):
        sub.append({"url": "loinc", "valueCode": r["loinc"]})
    sub.append({"url": "nombreContiene", "valueString": m["name"]})
    if cond.get("op") in (">", "<", ">=", "<="):
        sub.append({"url": "operador", "valueCode": cond["op"]})
        sub.append({"url": "umbral", "valueDecimal": cond["valor"]})
    if cond.get("unidad"):
        sub.append({"url": "unidad", "valueString": cond["unidad"]})
    sub.append({"url": "severidad", "valueCode": m["sev"]})
    for t in r["bloquea"]:
        sub.append({"url": "bloquea", "valueString": t})
    actions.append({
        "title": m["label"],
        "description": r["mensaje"],
        "condition": [{"kind": "applicability",
                       "expression": {"language": "text/fhirpath", "expression": fhirpath(r)}}],
        "extension": [{"url": GP_EXT, "extension": sub}],
    })

plandef = {
    "resourceType": "PlanDefinition",
    "id": PD_ID,
    "url": PLANDEF_URL,
    "identifier": [{"system": f"{BIO}/sid/plandefinition", "value": "gating-terapias"}],
    "version": "1.0",
    "name": "GatingTerapiasBioWellness",
    "title": "BioWellness — Gating de Terapias",
    "status": "active",
    "experimental": False,
    "publisher": "BioWellness San Isidro",
    "description": "Reglas de bloqueo de terapias avanzadas según biomarcadores. Las lee el Bot check-therapy-eligibility.",
    "type": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/plan-definition-type",
                          "code": "eca-rule", "display": "ECA Rule"}]},
    "action": actions,
}

bundle = {
    "resourceType": "Bundle", "type": "transaction",
    "entry": [{
        "fullUrl": f"urn:uuid:{PD_ID}",
        "resource": plandef,
        "request": {"method": "PUT", "url": f"PlanDefinition/{PD_ID}"},
    }],
}
json.dump(bundle, open("biowellness_plandefinition_gating_bundle.json", "w"), ensure_ascii=False, indent=2)
print(f"PlanDefinition id={PD_ID}")
print(f"url canonica (la usa el Bot)={PLANDEF_URL}")
print("actions:", [a["title"] for a in actions])
